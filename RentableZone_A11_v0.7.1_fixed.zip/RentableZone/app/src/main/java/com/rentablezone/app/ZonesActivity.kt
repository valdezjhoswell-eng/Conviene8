package com.rentablezone.app

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class ZonesActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private val savedPolygons = mutableListOf<Polygon>()
    private val currentPolygons = mutableListOf<Polygon>()
    private val zones = mutableListOf<SavedZone>()
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var selectedLocality = ""
    private var selectedRings = emptyList<List<GeoPoint>>()

    private data class LocalityResult(
        val label: String,
        val rings: List<List<GeoPoint>>,
        val latitude: Double,
        val longitude: Double,
        val south: Double,
        val north: Double,
        val west: Double,
        val east: Double
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = "RentableZone/0.7"
        setContentView(R.layout.activity_zones)

        zones.addAll(ZoneStore.load(this))
        map = findViewById(R.id.map)
        status = findViewById(R.id.txtPoints)
        spinner = findViewById(R.id.spZone)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(11.5)
        map.controller.setCenter(GeoPoint(-34.6037, -58.3816))

        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("🟢 VERDE — permitida", "🟡 AMARILLA — precaución", "🔴 ROJA — peligrosa")
        )
        spinner.setSelection(0)

        findViewById<Button>(R.id.btnSearchLocation).setOnClickListener { searchLocality() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveSelectedLocality() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearSelection() }

        drawSavedZones()
        updateStatus()
    }

    private fun searchLocality() {
        val query = findViewById<EditText>(R.id.eLocation).text.toString().trim()
        if (query.isBlank()) {
            toast("Escribe una localidad, barrio o partido")
            return
        }

        toast("Buscando localidades…")
        executor.execute {
            val results = requestLocalities(query)
            mainHandler.post {
                if (results.isEmpty()) {
                    toast("No encontré una localidad. Prueba, por ejemplo: Morón, Buenos Aires")
                    return@post
                }

                val labels = results.map { it.label }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Selecciona una localidad")
                    .setSingleChoiceItems(labels, -1) { dialog, which ->
                        dialog.dismiss()
                        selectLocality(results[which])
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    private fun requestLocalities(query: String): List<LocalityResult> {
        var connection: HttpURLConnection? = null
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = URL(
                "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1" +
                    "&polygon_geojson=1&limit=8&countrycodes=ar&q=$encoded"
            )
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 15000
                setRequestProperty("User-Agent", "RentableZone/0.7")
                setRequestProperty("Accept-Language", "es-AR,es;q=0.9")
            }
            if (connection.responseCode !in 200..299) return emptyList()
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            val array = JSONArray(text)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val lat = obj.optDouble("lat", Double.NaN)
                    val lon = obj.optDouble("lon", Double.NaN)
                    if (lat.isNaN() || lon.isNaN()) continue

                    val label = obj.optString("display_name", query)
                    val rings = parseGeometryRings(obj.optJSONObject("geojson"))
                    val bbox = obj.optJSONArray("boundingbox")
                    val south = bbox?.optString(0)?.toDoubleOrNull() ?: lat
                    val north = bbox?.optString(1)?.toDoubleOrNull() ?: lat
                    val west = bbox?.optString(2)?.toDoubleOrNull() ?: lon
                    val east = bbox?.optString(3)?.toDoubleOrNull() ?: lon

                    add(
                        LocalityResult(
                            label = label,
                            rings = rings,
                            latitude = lat,
                            longitude = lon,
                            south = south,
                            north = north,
                            west = west,
                            east = east
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseGeometryRings(geojson: JSONObject?): List<List<GeoPoint>> {
        if (geojson == null) return emptyList()
        return try {
            when (geojson.optString("type")) {
                "Polygon" -> parsePolygon(geojson.optJSONArray("coordinates"))
                "MultiPolygon" -> {
                    val polygons = geojson.optJSONArray("coordinates") ?: return emptyList()
                    buildList {
                        for (i in 0 until polygons.length()) {
                            val polygon = polygons.optJSONArray(i)
                            parsePolygon(polygon).firstOrNull()?.let { add(it) }
                        }
                    }
                }
                else -> emptyList()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parsePolygon(coordinates: JSONArray?): List<List<GeoPoint>> {
        if (coordinates == null) return emptyList()
        val outer = coordinates.optJSONArray(0) ?: return emptyList()
        val ring = buildList {
            for (i in 0 until outer.length()) {
                val pair = outer.optJSONArray(i) ?: continue
                if (pair.length() < 2) continue
                val lon = pair.optDouble(0, Double.NaN)
                val lat = pair.optDouble(1, Double.NaN)
                if (!lon.isNaN() && !lat.isNaN()) add(GeoPoint(lat, lon))
            }
        }
        return if (ring.size >= 3) listOf(ring) else emptyList()
    }

    private fun selectLocality(result: LocalityResult) {
        selectedLocality = result.label
        selectedRings = if (result.rings.isNotEmpty()) {
            result.rings
        } else {
            listOf(
                listOf(
                    GeoPoint(result.south, result.west),
                    GeoPoint(result.south, result.east),
                    GeoPoint(result.north, result.east),
                    GeoPoint(result.north, result.west)
                )
            )
        }

        map.controller.setCenter(GeoPoint(result.latitude, result.longitude))
        val spanLat = (result.north - result.south).coerceAtLeast(0.01)
        val spanLon = (result.east - result.west).coerceAtLeast(0.01)
        map.controller.setZoom(
            when {
                spanLat > 2 || spanLon > 2 -> 9.0
                spanLat > 0.8 || spanLon > 0.8 -> 10.5
                spanLat > 0.25 || spanLon > 0.25 -> 12.0
                else -> 13.5
            }
        )
        drawCurrentSelection()
        updateStatus()
        toast("Localidad seleccionada. Ahora elige el color y pulsa Guardar localidad")
    }

    private fun drawCurrentSelection() {
        currentPolygons.forEach { map.overlays.remove(it) }
        currentPolygons.clear()
        val c = zoneColor(spinner.selectedItemPosition)
        selectedRings.forEach { ring ->
            val polygon = Polygon(map).apply {
                ring.forEach { addPoint(it) }
                fillColor = Color.argb(65, Color.red(c), Color.green(c), Color.blue(c))
                strokeColor = c
                strokeWidth = 5f
                title = selectedLocality
            }
            currentPolygons += polygon
            map.overlays.add(polygon)
        }
        map.invalidate()
    }

    private fun saveSelectedLocality() {
        if (selectedRings.isEmpty()) {
            toast("Primero busca y selecciona una localidad")
            return
        }
        val type = spinner.selectedItemPosition
        selectedRings.forEach { ring -> zones += SavedZone(type, ring) }
        ZoneStore.save(this, zones)
        toast("Localidad guardada como ${zoneName(type)}")
        clearSelection()
        drawSavedZones()
    }

    private fun clearSelection() {
        selectedLocality = ""
        selectedRings = emptyList()
        currentPolygons.forEach { map.overlays.remove(it) }
        currentPolygons.clear()
        updateStatus()
        map.invalidate()
    }

    private fun drawSavedZones() {
        savedPolygons.forEach { map.overlays.remove(it) }
        savedPolygons.clear()
        zones.forEach { zone ->
            if (zone.points.size >= 3) {
                val polygon = Polygon(map).apply {
                    zone.points.forEach { addPoint(it) }
                    val c = zoneColor(zone.type)
                    fillColor = Color.argb(60, Color.red(c), Color.green(c), Color.blue(c))
                    strokeColor = c
                    strokeWidth = 5f
                    title = zoneName(zone.type)
                }
                savedPolygons += polygon
                map.overlays.add(polygon)
            }
        }
        map.invalidate()
    }

    private fun zoneColor(type: Int): Int = when (type) {
        0 -> Color.rgb(30, 170, 90)
        1 -> Color.rgb(220, 160, 20)
        else -> Color.rgb(210, 55, 70)
    }

    private fun zoneName(type: Int): String = when (type) {
        0 -> "VERDE — permitida"
        1 -> "AMARILLA — precaución"
        else -> "ROJA — peligrosa"
    }

    private fun updateStatus() {
        status.text = if (selectedLocality.isBlank()) {
            "Ninguna localidad seleccionada. Busca una y elígela de la lista."
        } else {
            "Localidad: $selectedLocality\nZona: ${zoneName(spinner.selectedItemPosition)}\nLista para guardar sin marcar puntos."
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { map.onPause(); super.onPause() }
    override fun onDestroy() { executor.shutdownNow(); map.onDetach(); super.onDestroy() }
}
